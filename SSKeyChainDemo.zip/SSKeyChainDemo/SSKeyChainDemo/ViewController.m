//
//  ViewController.m
//  SSKeyChainDemo
//
//  Created by M_Li on 2017/8/7.
//  Copyright © 2017年 M_Li. All rights reserved.
//

#import "ViewController.h"
#import "SSKeychain.h"
@interface ViewController ()

@end

NSString *const kUUIDKey = @"kUUIDKey";
NSString *const KEYCHAIN_SERVICE = @"KEYCHAIN_SERVICE";
NSString *const KEYCHAIN_ACCOUNT = @"KEYCHAIN_ACCOUNT";
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self getAppIdentifier];
}

- (NSString *)getAppIdentifier{
    
    NSString *UUID = [[NSUserDefaults standardUserDefaults] objectForKey:kUUIDKey];
    
    if (UUID == nil || [UUID isEqualToString:@""] || UUID.length == 0) {
        UUID = [SSKeychain passwordForService:KEYCHAIN_SERVICE account:KEYCHAIN_ACCOUNT];
        NSError *error=nil;
        
        if (UUID == nil || [UUID isEqualToString:@""] || UUID.length == 0){
            UUID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
            BOOL succcess= [SSKeychain setPassword:UUID forService:KEYCHAIN_SERVICE account:KEYCHAIN_ACCOUNT error:&error];
            if (succcess)
            {
                NSLog(@"第一次获取的UUID :%@", UUID);
            }
            [[NSUserDefaults standardUserDefaults] setObject:UUID forKey:kUUIDKey];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return UUID;
        }
        else {
            [[NSUserDefaults standardUserDefaults] setObject:UUID forKey:kUUIDKey];
            [[NSUserDefaults standardUserDefaults] synchronize];
            return UUID;
        }
    }
    else {
        NSLog(@"获取的UUID :%@", UUID);

        return UUID;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
